package com.Planner360.planner360;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Planner360ApplicationTests {

	@Test
	void contextLoads() {
	}

}
