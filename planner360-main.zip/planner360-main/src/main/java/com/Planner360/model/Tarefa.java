package com.Planner360.model;

import jakarta.persistence.*;
import java.time.LocalDate; // Representa a data da entrega

@Entity // Classe para tabela no banco de dados
public class Tarefa{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;

    private String titulo; // Título da tarefa
    private String descricao; // Descrição da tarefa
    private LocalDate dataEntrega;  // Data da entrega da tarefa

    @Enumerated(EnumType.STRING)
    private TipoTarefa tipo; // Tipo de tarefa (estudo, trabalho, pessoal)

    @Enumerated(EnumType.STRING)
    private StatusTarefa status; // Status da tarefa (Pendente, Em andamento, Concluida)

    @ManyToOne // Muitas tarefas poden pertencer a um único usuário
    @JoinColumn(name = "usuario_id") // Nome da coluna que faz ligação com a tabela usuário
    private Usuario usuario;

    // Getter e Setter para 'id'
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // Getter e Setter para 'titulo'
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    // Getter e Setter para 'descricao'
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    // Getter e Setter para 'dataEntrega'
    public LocalDate getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(LocalDate dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    // Getter e Setter para 'tipo'
    public TipoTarefa getTipo() {
        return tipo;
    }

    public void setTipo(TipoTarefa tipo) {
        this.tipo = tipo;
    }

    // Getter e Setter para 'status'
    public StatusTarefa getStatus() {
        return status;
    }

    public void setStatus(StatusTarefa status) {
        this.status = status;
    }

    // Getter e Setter para 'usuario'
    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}