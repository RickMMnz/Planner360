package com.Planner360.model; // Define o pacote onde a classe está

import jakarta.persistence.*; // Importa anotações JPA para mapeamento com o banco de dados
import java.util.List; // Importa a lista para representar as tarefas do usuário

@Entity // Diz ao Spring que essa classe é uma entidade do banco de dados
public class Usuario {

    @Id // Indica que esse campo é uma chave primária
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Gera o id automaticamente
    private long id;

    private String nome; // Nome do usuário
    private String email; // E-mail do usuário
    private String senha; // Senha do usuário

    @ManyToMany(fetch = FetchType.EAGER) // Um usuário pode ter vários papéis (ex: ROLE_USER, ROLE_ADMIN)
    @JoinTable( // Define a tabela intermediária entre Usuario e Papel
        name = "usuario_papel",
        joinColumns = @JoinColumn(name = "usuario_id"),
        inverseJoinColumns = @JoinColumn(name = "papel_id")
    )
    private List<Papel> papeis; // Lista de papéis atribuídos ao usuário

    @OneToMany(mappedBy = "usuario") // Um usuário pode ter várias tarefas
    private List<Tarefa> tarefas;

    // Getter e Setter para 'id'
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    // Getter e Setter para 'nome'
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    // Getter e Setter para 'email'
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter e Setter para 'senha'
    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    // Getter e Setter para 'papeis'

    public void setPapeis(List<Papel> papeis){
        this.papeis = papeis;
    }


    public List<Papel> getPapeis() {
        return papeis;
    }

    // Getter e Setter para 'tarefas'
    public List<Tarefa> getTarefas() {
        return tarefas;
    }

    public void setTarefas(List<Tarefa> tarefas) {
        this.tarefas = tarefas;
    }
}
