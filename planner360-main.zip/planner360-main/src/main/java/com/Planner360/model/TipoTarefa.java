package com.Planner360.model;

public enum TipoTarefa{
    ESTUDO,
    TRABALHO,
    PESSOAL
}