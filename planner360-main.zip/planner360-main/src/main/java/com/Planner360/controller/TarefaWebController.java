package com.Planner360.controller;

import com.Planner360.model.Tarefa;
import com.Planner360.model.Usuario;
import com.Planner360.service.TarefaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/app/tarefas")
public class TarefaWebController {

    @Autowired
    private TarefaService tarefaService;

    // Página de listagem de tarefas do usuário logado
    @GetMapping
    public String listarTarefas(@AuthenticationPrincipal Usuario usuario, Model model) {
        List<Tarefa> tarefas = tarefaService.listarPorUsuario(usuario.getId());
        model.addAttribute("tarefas", tarefas);
        return "tarefas/lista"; // templates/tarefas/lista.html
    }

    // Página de formulário para nova tarefa
    @GetMapping("/nova")
    public String novaTarefaForm(Model model) {
        model.addAttribute("tarefa", new Tarefa());
        return "tarefas/form"; // templates/tarefas/form.html
    }

    // Salvar nova tarefa
    @PostMapping("/salvar")
    public String salvarTarefa(@ModelAttribute Tarefa tarefa, @AuthenticationPrincipal Usuario usuario) {
        tarefa.setUsuario(usuario); // associa a tarefa ao usuário logado
        tarefaService.salvar(tarefa);
        return "redirect:/app/tarefas";
    }

    // Editar tarefa existente
    @GetMapping("/editar/{id}")
    public String editarTarefa(@PathVariable Long id, Model model) {
        Tarefa tarefa = tarefaService.buscarPorId(id).orElse(new Tarefa());
        model.addAttribute("tarefa", tarefa);
        return "tarefas/form"; // corrigido: templates/tarefas/form.html
    }

    // Excluir tarefa
    @GetMapping("/excluir/{id}")
    public String excluirTarefa(@PathVariable Long id) {
        tarefaService.deletar(id);
        return "redirect:/app/tarefas";
    }

    // Página de dashboard com resumo de tarefas
    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal Usuario usuario, Model model) {
        Long id = usuario.getId();
        model.addAttribute("total", tarefaService.contarTotalPorUsuario(id));
        model.addAttribute("pendentes", tarefaService.contarPendentesPorUsuario(id));
        model.addAttribute("emAndamento", tarefaService.contarEmAndamentoPorUsuario(id));
        model.addAttribute("concluidas", tarefaService.contarConcluidasPorUsuario(id));
        return "tarefas/dashboard"; // templates/tarefas/dashboard.html
    }
}
