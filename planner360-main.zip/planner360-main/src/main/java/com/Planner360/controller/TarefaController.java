package com.Planner360.controller;

import com.Planner360.model.Tarefa;
import com.Planner360.service.TarefaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/tarefas")
public class TarefaController {
    
    @Autowired
    private TarefaService tarefaService;

    //Lista todas as tarefas cadastradas
    @GetMapping
    public List<Tarefa> listarTodas(){
        return tarefaService.listarTodas();
    }

    //Busca uma tarefa por ID
    @GetMapping("/{id}")
    public Tarefa buscarPorId(@PathVariable Long id){
        return tarefaService.buscarPorId(id).orElse(null);
    }

    //Salva ou Atualiza uma tarefa
    @PostMapping
    public Tarefa salvar(@RequestBody Tarefa tarefa){
        return tarefaService.salvar(tarefa);
    }

    //Deleta uma tarefa pelo ID
    @DeleteMapping("/{id}")
    public void deletar(@PathVariable long id){
        tarefaService.deletar(id);
    }

    //Lista tarefas com Status Pendente ou Em_Andamento
    @GetMapping("/ativas")
    public List<Tarefa> listarAtivas(){
        return tarefaService.listarAtivas();
    }

    //Retorna um resumo com contagem de tarefas pro status - para Dashboard
    @GetMapping("/dashboard/{usuarioId}")
    public Map<String, Long> dashboard(@PathVariable Long usuarioId){
        Map<String, Long> dados = new HashMap<>();
        dados.put("total", tarefaService.contarTotalPorUsuario(usuarioId));
        dados.put("pendentes", tarefaService.contarPendentesPorUsuario(usuarioId));
        dados.put("emAndamento", tarefaService.contarEmAndamentoPorUsuario(usuarioId));
        dados.put("concluidas", tarefaService.contarConcluidasPorUsuario(usuarioId));
        return dados;
    }

}
