package com.Planner360.controller;

import com.Planner360.model.Usuario;
import com.Planner360.model.Papel;
import com.Planner360.repository.PapelRepository;
import com.Planner360.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/app/usuarios")
public class UsuarioWebController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private PapelRepository papelRepository;

    // Página de login
    @GetMapping("/login")
    public String loginPage() {
        return "usuarios/login"; // templates/usuarios/login.html
    }

    // Página de perfil do usuário
    @GetMapping("/perfil/{id}")
    public String perfil(@PathVariable Long id, Model model) {
        Usuario usuario = usuarioService.buscarPorId(id).orElse(new Usuario());
        model.addAttribute("usuario", usuario);
        return "usuarios/perfil"; // templates/usuarios/perfil.html
    }

    // Página de cadastro
    @GetMapping("/cadastro")
    public String cadastroForm(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "usuarios/cadastro"; // templates/usuarios/cadastro.html
    }

    // Salvar novo usuário
    @PostMapping("/salvar")
    public String salvarUsuario(@ModelAttribute Usuario usuario) {
        // Criptografa a senha
        usuario.setSenha(new BCryptPasswordEncoder().encode(usuario.getSenha()));

        // Atribui papel padrão ROLE_USER
        Papel papel = papelRepository.findByNome("ROLE_USER");
        usuario.setPapeis(List.of(papel));

        // Salva o usuário
        usuarioService.salvar(usuario);

        return "redirect:/app/usuarios/login";
    }
}
