package com.Planner360.config;

import com.Planner360.model.Papel;
import com.Planner360.model.Usuario;
import com.Planner360.repository.PapelRepository;
import com.Planner360.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.List;
import java.util.Optional;

@Configuration
public class CommandLineRunnerConfig {

    @Bean
    CommandLineRunner initDatabase(PapelRepository papelRepo, UsuarioRepository usuarioRepo) {
        return args -> {
            // Cria os papéis se ainda não existirem
            if (papelRepo.count() == 0) {
                papelRepo.saveAll(List.of(
                    new Papel("ROLE_USER"),
                    new Papel("ROLE_ADMIN")
                ));
            }

            // Verifica se o usuário admin já existe
            Optional<Usuario> adminExistente = usuarioRepo.findByEmail("admin@planner360.com");
            if (adminExistente.isEmpty()) {
                Usuario admin = new Usuario();
                admin.setNome("Administrador");
                admin.setEmail("admin@planner360.com");
                admin.setSenha(new BCryptPasswordEncoder().encode("123456"));

                // Associa os papéis ao usuário
                List<Papel> papeis = List.of(
                    papelRepo.findByNome("ROLE_USER"),
                    papelRepo.findByNome("ROLE_ADMIN")
                );
                admin.setPapeis(papeis);

                usuarioRepo.save(admin);
            }
        };
    }
}
