package com.Planner360.planner360;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.Planner360")
@EnableJpaRepositories(basePackages = "com.Planner360.repository")
@EntityScan(basePackages = "com.Planner360.model")
public class Planner360Application {

    public static void main(String[] args) {
        SpringApplication.run(Planner360Application.class, args);
    }
}
