package com.Planner360.service;

import com.Planner360.model.Tarefa;
import com.Planner360.model.StatusTarefa;
import com.Planner360.repository.TarefaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Arrays;
import java.util.Optional;

@Service
public class TarefaService {

    @Autowired
    private TarefaRepository tarefaRepository;

    // Buscar todas as tarefas
    public List<Tarefa> listarTodas() {
        return tarefaRepository.findAll();
    }

    public List<Tarefa> listarPorUsuario(Long usuarioId) {
    return tarefaRepository.findByUsuarioId(usuarioId);
}

    // Buscar tarefa por ID
    public Optional<Tarefa> buscarPorId(Long id) {
        return tarefaRepository.findById(id);
    }

    // Salvar ou atualizar tarefa
    public Tarefa salvar(Tarefa tarefa) {
        return tarefaRepository.save(tarefa);
    }

    // Deletar tarefa por ID
    public void deletar(Long id) {
        tarefaRepository.deleteById(id);
    }

    // Buscar tarefas com status PENDENTE ou EM_ANDAMENTO
    public List<Tarefa> listarAtivas() {
        return tarefaRepository.findByStatus(Arrays.asList(StatusTarefa.PENDENTE, StatusTarefa.EM_ANDAMENTO));
    }

    // Contagem de tarefas por status (para dashboard)
    public long contarConcluidasPorUsuario(Long usuarioId) {
        return tarefaRepository.countByStatusAndUsuarioId(StatusTarefa.CONCLUIDA, usuarioId);
    }

    public long contarPendentesPorUsuario(Long usuarioId) {
        return tarefaRepository.countByStatusAndUsuarioId(StatusTarefa.PENDENTE, usuarioId);
    }

    public long contarEmAndamentoPorUsuario(Long usuarioId) {
        return tarefaRepository.countByStatusAndUsuarioId(StatusTarefa.EM_ANDAMENTO, usuarioId);
    }

    public long contarTotalPorUsuario(Long usuarioId) {
        return tarefaRepository.countByUsuarioId(usuarioId);
    }
}